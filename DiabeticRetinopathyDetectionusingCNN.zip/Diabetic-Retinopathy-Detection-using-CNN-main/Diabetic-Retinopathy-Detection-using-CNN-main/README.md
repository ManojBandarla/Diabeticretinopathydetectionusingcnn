# Diabetic-Retinopathy-Detection-using-CNN

![11](https://user-images.githubusercontent.com/74102314/226185488-928a1bb2-a169-4cf5-b60e-2018eeecae01.png)
![Uploading 22.png…]()

Note � Use the images that are recently collected for the better output results.
Compare with other projects in order to get the better accuracy of ur project.



Project by: B. Manoj (19699A0448).
College - Madanapalle institute of technology and sciences.
    College mail - 19699A0448@mits.ac.in
    Personal mail � manojbandarla@gmail.com


